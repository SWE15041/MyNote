export function supportBigInt() {
    return typeof BigInt === "function";
}
