export default {
    host: "envoyforpartners.foodtruck-qa.com",
    logServerURL: "https://event.foodtruck-qa.com/event/envoyforrestaurantsV2",
    env: "QA",
    amplitudeApiKey: "df02bdb0daf9955fc424586d078245a2",
};
