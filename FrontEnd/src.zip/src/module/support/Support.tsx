import React from "react";

const Support = () => {
    return (
        <div className="support-page">
            <h1>support page</h1>
        </div>
    );
};

export default Support;
