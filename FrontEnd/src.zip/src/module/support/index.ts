import {module} from "./module";
import SupportComponent from "./Support";
export const Support = module.attachLifecycle(SupportComponent);
