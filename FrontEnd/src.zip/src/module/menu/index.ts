import {module} from "./module";
import MenuComponent from "./Menu";
export const Menu = module.attachLifecycle(MenuComponent);
