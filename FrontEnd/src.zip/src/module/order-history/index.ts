import {module} from "./module";
import OrderHistoryComponent from "./OrderHistory";
export const OrderHistory = module.attachLifecycle(OrderHistoryComponent);
