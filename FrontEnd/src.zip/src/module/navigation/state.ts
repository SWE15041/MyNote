import {State} from "./type";

export const initialState: State = {};
