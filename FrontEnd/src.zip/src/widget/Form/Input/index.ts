export {CustomerInput as Input} from "./Input";
export {CustomerInputPassword as InputPassword} from "./InputPassword";
export {InputNumber} from "./InputNumber";
export {InputNumberV2} from "./InputNumberV2";
export {EmailInput} from "./EmailInput";
